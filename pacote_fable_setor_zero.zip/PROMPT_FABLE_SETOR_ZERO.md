# PROMPT — Setor Zero (campo de treinamento) + Tutorial da Iris

> Cole este arquivo inteiro como primeira mensagem ao agente, com o repositório do jogo aberto e os anexos
> listados na seção 1 já colocados nas pastas indicadas. Ele é longo de propósito: cada decisão já está tomada
> aqui, e o que não está está marcado como **DECIDA E REGISTRE**.

---

## 0. Quem você é, o que é o projeto e as regras que não se quebram

Você vai trabalhar no **WolfLeague** (nome público; o nome antigo "Alcateia" **nunca** aparece em texto de jogador,
em legenda, em letreiro, em loja, em crédito — só sobrevive em nomes internos de projeto, namespaces e arquivos que
já existem; não renomeie esses). É um FPS multiplayer com transformação humano ↔ lobo, em **Godot 4.7 + C#**, com
servidor .NET (`servidor/`) e painel React. O dono do projeto é o Jhon. **Responda sempre em português do Brasil,
direto e honesto.** Diga o que não conseguiu, o que não testou e o que acha ruim; não enfeite.

**Antes de escrever uma linha:** leia inteiros `CLAUDE.md` (= `AGENTS.md`), `docs/DESIGN.md` (seções de movimento,
lobo, chamas/Rage, conjuntos), `docs/MAPAS.md`, `docs/CONJUNTOS.md`, `docs/AUDIO.md`, `docs/SONS_IA.md`,
`docs/UI.md`, `docs/ARQUITETURA.md`, `docs/AJUSTES.md`, `CONTRIBUTING.md` e `docs/TUTORIAL_ROTEIRO.md`. Depois
leia o código que vai tocar: `scripts/core/InputSetup.cs`, `scripts/core/Sfx.cs`, `scripts/core/MapLoader.cs`,
`scripts/meta/Maps.cs`, `scripts/forms/FormController.cs`, `scripts/domain/Rage.cs`, `scripts/ui/LoadoutMenu.cs`,
`scripts/ui/hud/Hud.cs`, `scripts/debug/Dummy.cs`, `scenes/treino.tscn`, `scripts/lobby/LoginScreen.cs`,
`scripts/lobby/AccountGate.cs`, `scripts/lobby/LobbyScreen.cs`, `tools/mapas/kit.py` e um mapa de referência
(`tools/mapas/neon.py` e `tools/mapas/polar.py`).

### Regras duras

1. **Não faça commit, push, tag, deploy nem mexa em Fly/produção.** Deixe tudo na árvore de trabalho para o Jhon
   revisar. Se precisar, sugira a mensagem de commit no final.
2. **Nenhum segredo** em arquivo, log ou mensagem: nada de token do Discord, credencial da Meshy, chave do Fly,
   senha de banco. Se um passo exigir uma chave, **pare e peça** em vez de inventar um lugar para guardá-la.
3. **Não reproduza** obra de terceiros: as imagens de referência (campo de treino de outro jogo) servem de
   *inspiração de organização* (arsenal, antena, faixa de perigo, baias), nunca de cópia de forma, letreiro ou
   marca. Nada de nome, logo ou arte de outros jogos em nenhum arquivo.
4. **Licença de tudo que entra:** só asset com licença que permita uso comercial, e com a linha dele em
   `assets/audio/CREDITOS.md` (som) ou `docs/PACOTES.md` (arte) **no mesmo conjunto de alterações**.
5. **Regras de design do CLAUDE.md valem** (mesma gramática de controle em todas as formas, humano lento e
   pesado, nada de vantagem permanente...). O tutorial **ensina** as regras, não as muda. Se o tutorial exigir uma
   mudança de regra de jogo, pare e pergunte.
6. **Não misture rede com regra de jogo.** O treino roda **offline**, sem servidor de partida.
7. **Número novo → linha no `docs/AJUSTES.md`. Decisão de jogo → `docs/DESIGN.md`. Mapa → `docs/MAPAS.md`.
   Mudança visível → `docs/CHANGELOG.md`.**
8. **Rode `tools/testar.sh --rapido` antes e depois** de cada fase e cole o resultado no relatório. Nada de "deve
   funcionar": diga o que rodou e o que não rodou (a nuvem não roda Forward+ em tempo útil; fotos de mapa e
   conferência visual são do Mac do Jhon — veja a seção 9).
9. **Mensagens de commit, comentários de código e documentação em português**, no estilo que o repo já usa
   (comentários que explicam o *porquê*, com a decisão e a data quando for do Jhon).

---

## 1. O que você recebe (anexos) e onde colocar

O Jhon vai entregar estes arquivos. Se algum faltar, **liste o que faltou no começo do relatório** e siga com o que
tem — não invente o conteúdo de um anexo.

| Anexo | O que é | Onde colocar |
|---|---|---|
| `planta_treinamento.png` / `.svg` | A planta v4 do Setor Zero (vista de cima, 1 quadrado = 10 m). **É a fonte de verdade do layout.** | `docs/tutorial/planta_setor_zero.png` e `.svg` |
| `planta.py` | O script matplotlib que gerou a planta (todas as coordenadas das peças estão nele) | `tools/tutorial/planta.py` |
| `TUTORIAL_ROTEIRO.md` | O roteiro com a Iris (etapas, falas, o que o jogo espera, dicas, fechamento, reservas) | já está em `docs/TUTORIAL_ROTEIRO.md`; **leia a versão do repo**, ela vence se divergir |
| `vozes_tutorial_iris.zip` | As falas da Iris, cortadas de um MP3 único (`voz_tutorial_<etapa>.wav`, mono 44,1 kHz), mais `LEIA-ME.md` e o MP3 original | extraia para `assets/audio/` só os `.wav` finais (veja a fase 3); o MP3 original vai para `assets/audio/_fontes/` fora do export |
| Fotos de referência (3 imagens de um campo de treino de outro jogo) | Inspiração de **organização** (arsenal, antena, painéis de baia, faixa amarela/preta) | só para olhar; **não** copie para o repo |

### Limites conhecidos das vozes (leia o `LEIA-ME.md` do zip)

- Os cortes foram feitos por silêncio e conferidos por reconhecimento de fala **impreciso**. Os pontos incertos
  são `1_3/1_4`, `1_6/2_0`, `2_5/2_6` e `3_1/3_2`. **Você não consegue ouvir.** Não finja que conferiu: valide
  por duração (cada fala de 1 a 5 s, sem silêncio de mais de 0,4 s nas pontas) e deixe uma **tabela de conferência
  humana** (fase 3) para o Jhon ouvir.
- **Faltam:** a etapa `4_3` ("Hold E any time to see your abilities."), **todas as dicas** (`_dica`, aos 12 s e
  25 s) e as reservas "Nice." e "Exactly.". O sistema precisa funcionar **sem** essas falas (a legenda cobre) e
  pegá-las sozinho quando o arquivo aparecer — nada de `if` por etapa.
- `4_2b` e `4_2b_alt` são duas gravações da mesma fala: use `4_2b` e guarde `4_2b_alt` como variante.
- `sem_destino_44` é um trecho sem fala conhecida: **não use**; deixe fora do export.
- As vozes foram geradas no plano **gratuito** do ElevenLabs, que **não permite uso comercial**: registre isso em
  `assets/audio/CREDITOS.md` e em `docs/SONS_IA.md` como pendência de **regerar em plano pago antes do lançamento**.

---

## 2. Entregas e ordem (não pule fases; cada uma termina com critério de aceite)

| Fase | Entrega | Aceite |
|---|---|---|
| 1 | **Mapa `setor_zero`**: blockout jogável (`montar()`) + testes | Dá para andar de ponta a ponta; todos os obstáculos do tutorial são vencíveis por um jogador de teste; `testar.sh --rapido` verde |
| 2 | **Acabamento** (`acabamento()`): arte, luz, textura, vegetação, fundo, letreiros | Dentro dos padrões do jogo; sem peça fora do kit/paleta; sem área vazia; fotos do mapa tiradas pelo Jhon |
| 3 | **Vozes + som**: importar, nomear, ligar no `Sfx`, tabela de conferência | Toda fala existente toca; as que faltam não quebram nada |
| 4 | **Motor do tutorial**: `roteiro.json`, máquina de etapas, eventos, HUD da Iris (legenda, marcador, tecla), dicas 12/25/40 s, pontos de salvamento, sair/retomar | O roteiro roda inteiro offline; testes automáticos passam |
| 5 | **Integração**: tela de entrada pós-login, Jogar → Treinamento, recompensa única por conta (servidor), refazer sem recompensa | Fluxo completo; servidor com teste; sem regressão |
| 6 | **Documentação e relatório final** | Docs atualizados; relatório no formato da seção 10 |

Trabalhe **uma fase por vez**, rode os testes ao fim de cada uma e **mostre o estado** antes de seguir. Se uma
fase bloquear (falta anexo, teste que você não consegue rodar, decisão do Jhon), registre e passe para o que não
depende dela.

---

## 3. FASE 1 e 2 — O mapa Setor Zero

### 3.1 O conceito (não mude sem perguntar)

- **Nome:** **Setor Zero**, o centro de treinamento da WolfLeague. Id do mapa: `setor_zero`. Cena
  `scenes/maps/setor_zero.tscn`, gerada por `tools/mapas/setor_zero.py` (mesmo padrão dos outros:
  `montar()` = o jogo; `acabamento()` = o lugar).
- **Tema:** **cyberpunk de dia**, um campus de treinamento no alto do **Distrito Neon**. Sol alto, céu limpo,
  sombras nítidas; LED e telões holográficos **brilham mesmo ao sol**. Concreto claro, aço escuro, vidro cromado,
  jardim e bosque. Pense em "academia de elite" — limpo, legível, sem sujeira, sem objeto jogado.
- **Do Distrito Neon:** skyline de torres de vidro e cromo ao fundo (usar o que já existe em
  `tools/mapas/kits/fundos.py` e o kit sci-fi/`LP_SciFiCity`), painéis de parede, escadas, postes, letreiros, LED.
- **De outros mapas:** Polar (faixa de perigo amarela/preta, contêiner, cisterna, letreiros de setor); Estação
  (passarela elevada, lanternas de teto); Cidade (bancos, postes, sebes).
- **Regra de ouro (do Jhon):** **nada de objeto aleatório e nada sem função.** Cada peça é cobertura, alvo, marca,
  orientação, luz ou paisagem **fora do caminho**. Sem caixote solto, sem carro, sem lixo, sem prop que bloqueie a
  mira. E **nada de área grande vazia**: todo trecho tem caminho, construção, pista, jardim ou prop com função.
- **Offline e fora da rotação:** não aparece na escolha de mapa das salas (`Maps.All` marca o mapa como
  `Treino`/oculto da rotação; descubra como `Maps.cs` esconde um mapa e use o mesmo mecanismo). Só abre pelo
  tutorial e por **Jogar → Treinamento**.

### 3.2 Convenções de coordenadas

- A planta usa **1 unidade = 1 m**, origem no canto superior esquerdo, **x para a direita, y para baixo**, o campo
  vai de (0,0) a (150,100) dentro do muro perimetral (que fica em x −3…153, y −3…103).
- No Godot: **X = x − 75**, **Z = y − 50**, **Y** para cima, **chão em Y = 0** (o campo é plano; os desníveis são
  as peças). O norte da planta (topo) é **−Z**.
- Convenção de times do jogo (azul nasce em −X e olha para +X) **não se aplica**: o treino tem um spawn só
  (Sala de Ativação, x = 12, y = 50, olhando para +X, isto é, para o corredor).

### 3.3 O que a planta mostra — zona por zona

Tudo abaixo está desenhado na planta v4; os números vêm do `planta.py`. **Onde um número da planta conflita com a
física do jogo (veja 3.4), a física vence e você registra o ajuste.**

**Núcleo da Iris** (hub) — círculo de **r = 12 m** centrado em (75, 50). Piso de concreto polido claro, anel
tracejado interno de r = 4 m (marca holográfica no chão) e anel pontilhado de r ≈ 8 m. No centro, o **holograma
da Iris** (placa/pilar de luz ciano, sem rosto humano; pode ser um busto estilizado de luz). Saídas: oeste
(corredor 43 × 6 m até a Sala de Ativação), norte (passagem de 4 m, x 73–79, y 34–38, para a Linha de Fogo), leste
(salão 16 × 6 m até a Câmara de Metamorfose, x 87–103, y 47–53) e sul (passagem x 73–79, y 62–64, para a Arena da
Matilha). Cada saída tem **porta de energia amarela** (a Iris abre uma de cada vez; veja 5.4). Letreiro: "NÚCLEO
DA IRIS".

**Sala de Ativação** (zona 1) — x 4–20, y 38–62 (16 × 24 m), teto 5 m. Spawn em (12, 50). Armários de 1,5 m na
parede oeste (x 4,6–6,1, y 41–59), bancos (y ≈ 59,4), vasos. Porta para o corredor em x = 20, abertura central
y 44,5–55,5. Parede norte com **janela larga** para o Jardim Suspenso. Letreiro "SALA DE ATIVAÇÃO".

**Corredor de Calibragem** — x 20–63, y 47–53 (6 m de largura), pé-direito 4 m, **sem teto fechado** (vigas
abertas ou pergolado de LED). LED forte no piso nos dois lados (y 47,35 e 52,65). Jardineiras de 1 m ao longo
dos dois lados (**baixas, que não bloqueiam o pulo**). Etapas físicas, em ordem:
- **Marcas no chão** (x ≈ 24–27): placas de piso luminosas; o "chegou na marca" da etapa 1.2 é uma **zona** de
  ~1,6 m em volta delas.
- **Vão** em x ≈ 31–35 (planta: 4 m; **veja 3.4: a largura real é menor**): fosso com **piso de reset** no
  fundo (cair = voltar para a marca anterior, sem dano, com fade curto). Hachura vermelha no chão, letreiro "VÃO".
- **Viga** em x ≈ 42–44: travessa baixa que obriga a agachar; **vão livre = `CrouchHeight` (1,0 m) + 0,25 m**, e
  o jogador em pé **tem que bater** nela (colisão real, sem passagem). Letreiro "VIGA".
- **Trecho silencioso** em x ≈ 49–61: **zona de andar devagar** (Shift); piso de outra textura (borracha/painel
  acústico) para o jogador entender a mudança; a etapa 1.5 conta **3 s andando devagar dentro dela**.

**Linha de Fogo** (zona 2) — x 45–105, y 2–34 (**60 × 32 m**), **a céu aberto** (céu e painéis de luz), muros
laterais de ~6 m. Letreiro grande "LINHA DE FOGO". Peças (coordenadas da planta):
- **Linha de tiro** em y = 28 (do x 50 ao 100), faixa amarela/preta no piso (como no `planta.py`) e **seis
  cabines** (divisórias) a cada 10 m: "cabine 1…5".
- **Alvos próximos** a 7 m da linha: (60, 21), (75, 21), (90, 21). **Alvos médios** a ~15 m: (58, 13), (75, 13),
  (92, 13). **Alvo distante** a 20 m: (75, 7,8). Todos são o **Dummy** (`scripts/debug/Dummy.cs`) em estado
  "parado"; veja 6.3 para os estados.
- **Estação da pistola:** x 46–56, y 20–28, dois alvos em (49, 24,5) e (53, 24,5); a etapa 2.5 espera **um
  boneco derrubado com 2 tiros** (use o Dummy com vida suficiente para 2 tiros da pistola e **não** 1).
- **Corpo a corpo:** x 46–54, y 29,5–34, dois bonecos em (48, 31,7) e (52, 31,7) (coronhada V e faca 4).
- **Poço da granada:** x 94–104, y 7–17,5; **muro** de ~2,4 m em x 94–104, y 15–16,4; **alvo atrás do muro** em
  (99, 10). A etapa 2.8 exige a granada **explodir perto do alvo** (raio definido por você, veja 6.4).
- **Trilho do alvo móvel:** y = 25,2, x 78–100, carrinho de 3 m com um Dummy em estado "móvel".
- **Bancada de recarga** (x 46,6–54,6, y 8,4–14), **depósito de alvos** (x 95,5–103, y 21,5–25,1), **arsenal**
  (letreiro "ARSENAL" em x 46–55, y 2,6–4,8), coberturas baixas de 1 m em y 15,6 (x 62, 68, 82, 86) — 0,8 m de
  altura se for para o humano subir/agachar atrás, 1,2 m se for só cobertura (**decida e registre**).
- Postes com lâmpada ao longo dos muros leste e oeste.

**Câmara de Metamorfose** (zona 3) — círculo **Ø 18 m** centrado em (112, 50). Piso com **anel de energia**
central de r = 3 m e o numeral "3"; é onde a Iris manda **apertar 3**. Salão de ligação com o Núcleo: x 87–103,
y 47–53. **Duas saídas novas** (a planta mostra as passagens): **sul**, x 112–118, y 59–64, para a Arena da
Matilha; **norte**, x 109–115, y 36–41, para a Rua Ignição. Domo de vidro leve. Letreiro "CÂMARA DE METAMORFOSE".

**Arena da Matilha** (zona 4) — x 40–120, y 64–98 (**80 × 34 m**), **paredes de 14 m** (para o lobo não alcançar
o topo; veja 3.4). Letreiro "ARENA DA MATILHA". Materiais: concreto + rocha com musgo na base. Peças:
- **Reta de corrida:** 42 m livres em y ≈ 70,5, de x 44 a 86 (a etapa 3.4 pede 2 s de corrida de quatro).
- **Plataformas de bote:** 6 × 6 m em (58–64, 82–88) com **3 m** de altura e (70–76, 82–88) com **6 m**;
  alvos em (61, 78,8) e (73, 78,8). **Confirme as alturas contra o lobo real** (3.4).
- **Vão do salto:** x 46–54, y 80–92 (8 × 12 m), fosso com piso de reset; alvo do outro lado em (43, 86).
- **Parede de corrida:** 32 m contínuos em y = 97,2, de x 84 a 116, 14 m de altura, **sem janela nem quina**;
  é a etapa 3.7/3.8. Faixa de LED na altura de cada metro como guia.
- **Círculo do uivo:** centro (106, 78), r = 3 m (etapa 3.9).
- **Agrupamento para o especial (Q):** 4 alvos em (90, 80), (92,2, 81,6), (87,8, 81,6), (90, 83,4).
- **Rampa longa de 18°:** x 79–95, y 87,6–93,4, com chevrons no piso. **Pilares de 9 m** (diâmetro ~1,8 m) em
  y = 95, x = 58, 63, 68, 73, 78 (apoio do bote). Rochas e uma **mata baixa** no canto nordeste; tira de
  vegetação em x 118–119,4, y 66–96.
- **Corredor oeste** x 30–40, y 80–85 liga ao Ponto de Retorno.

**Rua Ignição** (zona 5) — x 106–146, y 4–36 (40 × 32 m). Letreiro "RUA IGNIÇÃO". Dois **prédios** (x 112–124 e
128–140, y 10–18, altura ~6 m) ligados por uma **passarela** elevada (x 124–128, y 12,6–14,8) com escada. **Três
portões de onda** (A em x ≈ 111, B em 126, C em 141, y ≈ 19,5–20,9) de onde saem os bonecos da etapa 4.0, em
sequência com 1,5 s entre eles. Coberturas: caixas em (120, 27), (132, 26), (126, 31) e barricadas baixas (veja
o `planta.py`). **Painel do KP** (x 140–145, y 26–34): um telão que mostra o contador de KP em tamanho grande
(diegético; o número real continua sendo o do HUD). Portas dos prédios em y ≈ 17,4. É o cenário da etapa **"em
chamas"** (bloco 4).

**Ponto de Retorno** (zona 6) — x 4–30, y 70–96 (26 × 26 m). Letreiro "PONTO DE RETORNO". **Quatro pedestais** de
4 × 4 m em y 78–82 (x ≈ 6, 11,5, 17, 22,5; numerados 1–4) + um **círculo "L"** (lobo) em (26, 90) e o **portal
"JOGAR"** em x 5–14, y 92–95. É onde o jogador **renasce** no bloco 5. Bancos, vasos, um telão de KP.

**Áreas de apoio (preenchem o campo; todas com função):**
- **Jardim Suspenso** (x 4–44, y 3–35): gramado, bordos, sebes baixas, **espelho d'água**, bancos, lâmpadas,
  **Torre de Controle** (x 29–38, y 6–15, sala de observação de 12 m com **antena parabólica**) e cisterna. Livre,
  **sem etapa**. Passa pela janela da Sala de Ativação.
- **Quadra de Agilidade** (x 22–31, y 37–44): quadra marcada com cones (ornamental/aquecimento, **sem etapa**).
- **Posto Médico** (x 46–54,5, y 36,2–41,8) e **Café do Setor** (kiosque x 90–97, y 36,6–41 com 3 mesas): são
  cenário de descanso; **não** dão vida nem item (para não criar regra nova).
- **Praça do Uivo** (x 123–149, y 39–63): praça pavimentada com **estátua do lobo** (r ≈ 3 m) no centro, bancos,
  4 árvores nos cantos, lâmpadas.
- **Pinhal da Matilha** (x 121–149, y 65–99): bosque de **pinheiros de 18 a 25 m** (acima dos muros da arena),
  trilha, rochas.
- **Pátio técnico** (x 31–39, y 64–98): contêineres de material (estilo Polar), bancos, lâmpadas.
- **Bordas:** pista de serviço (norte, com baias de drone), **alameda** (oeste, árvores a cada 9 m), **canteiro**
  (leste, sebe de 94 m + árvores), **pista de aquecimento** de 4 raias (sul, 148 m, y 99,3–102,5, em borracha).
- **Muro perimetral** de 5 m com painéis/telões e o **skyline** do Distrito Neon em três camadas (perto, meio,
  longe) vendo-se por cima do muro. **Barreira invisível só onde o muro não alcança** (o muro de fora não segura a
  corrida em parede do lobo: veja `Player.BackedByBarrier`).

### 3.4 Física: onde a planta precisa ser corrigida (LEIA)

A planta é um **desenho**; as medidas do jogo vêm do código. Antes de fechar o blockout, **meça no código e nos
testes** (não de memória) e ajuste:

- **Vão de pulo do humano:** a planta diz 4 m, mas o **avanço do pulo correndo do humano é ~2,7 m**
  (`CLAUDE.md`, "Regras de design" 9). **Faça o vão ter no máximo ~2,0 m** (margem para quem pula sem correr) e
  confirme com um teste que o jogador de teste atravessa. Registre o número final.
- **Viga:** vão livre = `Player.CrouchHeight` (1,0 m) + 0,25 m, e o jogador em pé (`StandHeight` 1,75 m) deve ser
  bloqueado.
- **Vão do lobo (8 m) e plataformas de 3 m e 6 m:** o pulo do lobo é "para cima, não para a frente" (~3,8 m de
  avanço; altura do Bruto 1,62 m, do Ligeiro 2,50 m; terraço a 5 m só por rampa ou ricochete em beco de 3 m). **A
  etapa 3.5 diz "carregue um salto" e a 3.6 "ataque de cima"**: descubra em `Weapon.WolfClaws`/`WolfMoves` e nos
  testes `WolfMovesTests` o **alcance e a altura reais do salto carregado e do bote**, e **dimensione o vão e as
  plataformas para serem vencidos com folga de ~15%, nas duas classes do lobo**. Se a altura de 6 m não for
  alcançável, rebaixe (a regra "alturas presas à física" do `MAPAS.md` manda).
- **Parede de corrida:** 14 m de altura, 32 m de comprimento, sem janela. Confirme o comprimento mínimo da
  corrida em parede (velocidade na parede 4,45 / 4,82 m/s) para o "2 s" da etapa 3.7 caber com folga.
- **Rampas:** todo desnível que o bot precisa vencer tem rampa (degrau máximo 0,5 m). A escada leva a chapa de
  rampa só de colisão (`M.rampa`).
- **Pontos de nascimento e rotas:** o jogo exige 8 spawns por time e rotas de ronda nos mapas de partida; o
  Setor Zero **não** é mapa de partida. Faça **1 spawn de jogador** (Sala de Ativação) e o `NascerLivre` mínimo
  que o `MapLoader`/testes de mapa exigirem. Descubra em `tests/regression/MapTests.cs` quais verificações
  valem para um mapa fora da rotação e **trate de forma explícita** (marque o mapa como "treino" no teste em vez
  de enfraquecer o teste).

### 3.5 Duas camadas

1. **`montar()` — o jogo.** Caixas, rampas, cilindros com colisão, zonas, spawn, alvos. É o que os testes medem.
2. **`acabamento()` — o lugar.** Quase tudo **sem colisão**: fachadas, janelas, vegetação, postes, letreiros,
   skyline. Quando a forma que se vê é mais rica que a caixa, a caixa fica `oculta=True` (colisão sem desenho).

### 3.6 Luz e texturas (padrão do jogo — não invente outro)

- **Luz:** `luz_de_jogo(m, "dia", yaw, queda)` em `tools/mapas/kits/montagem.py`, clima **`dia`**: sol quente e
  forte, sombra fria e clara, ambiente azul-violeta (vão, sala e beco **nunca pretos**), luz fraca sem sombra para
  cima, **SSAO largo + SSIL**, **ACES (branco 6,5)**, névoa com perspectiva aérea, sol com tamanho (sombra macia).
  **Mapa aberto: sem SDFGI.** As salas fechadas (Sala de Ativação, Câmara de Metamorfose, Ponto de Retorno) usam
  `foco` (luminária de teto com sombra). Postes: `lampadas(m, [M])`, lâmpada quente sem sombra.
- **Céu:** `dia_claro` (HDRI já existente em `assets/mapas/ceus/`; confirme o nome). `giro` calculado como em
  `tools/mapas/vila.py`. **Sem neblina forte.**
- **Textura:** o material `assets/mapas/detalhe/scifi.tres` + `superficie.gdshader` (grão projetado no mundo). Use
  as **27 classes** de `tools/mapas/kits/detalhe.py`: **asfalto, piso, calçamento, faixa** (chão), **concreto,
  reboco, metal pintado, metal cru, vidro** (prédios; o vidro reflete o céu), **folhagem, tronco** (verde),
  **rocha, brita** (bases e trilhas), **água** (espelho d'água), **borracha** (pista de aquecimento e trecho
  silencioso), **plástico/tecido/madeira** (bancos, toldos). Se uma peça sair com o material errado: uma linha em
  `PECAS`/`FIXAS`, rode `python3 tools/mapas/detalhar.py` e reimporte.
- **LED e letreiros:** LED de verdade (`scifi_luz.png`) e **lâmpada na cor do letreiro**. Todo texto escrito no
  mapa é uma imagem de `tools/mapas/letreiros.py` (**Overpass**, **Saira Stencil**, **Bebas Neue**; nunca
  `Label3D`): `m.letreiro(grupo, "Nome", "setor_zero_<nome>", pos, largura, yaw)` na parede, ou `chao=True` pintado
  no piso, ou `aceso=0.5` para painel luminoso. **Lista dos letreiros** (uma linha em `_lista()` cada): SETOR ZERO,
  NÚCLEO DA IRIS, SALA DE ATIVAÇÃO, CORREDOR DE CALIBRAGEM, VÃO, VIGA, TRECHO SILENCIOSO, LINHA DE FOGO, ARSENAL,
  CABINE 1…5, POÇO DA GRANADA, CÂMARA DE METAMORFOSE, ARENA DA MATILHA, PAREDE DE CORRIDA, CÍRCULO DO UIVO, RAMPA
  LONGA, RUA IGNIÇÃO, ONDA A/B/C, PONTO DE RETORNO, PORTAL JOGAR, PRAÇA DO UIVO, CAFÉ DO SETOR, POSTO MÉDICO,
  TORRE DE CONTROLE, JARDIM SUSPENSO, QUADRA DE AGILIDADE, PISTA DE AQUECIMENTO. Faixas de perigo e marcas de
  setor **pintadas no piso**.
- **Árvores/pinheiros:** poucos modelos **repetidos** (custo baixo). Se o kit não tiver, use o que já está nos
  pacotes de `docs/PACOTES.md` (Poly Haven/Kenney/Quaternius, licença CC0); **não invente modelo procedural feio**:
  se não houver peça aceitável, **pare e liste o que falta** (veja 3.8).
- **Acústica:** `MapInfo.RoomSize`/`RoomWet` e `Ambience`: aberto, pouco eco; ambiente de dia urbano ao longe (use
  um som que já exista ou peça um novo na lista de pendências; **não** gere som).

### 3.7 Critérios de pronto do mapa

- Sem área vazia grande: **escreva um script de conferência** (`tools/mapas/conferir.py` já existe, veja o
  padrão) que divide o campo em quadrados de 5 m e **falha** se algum quadrado dentro do muro não tiver nenhuma
  peça (piso especial, prop, vegetação, construção ou pista) — o Jhon odeia mapa com vazio.
- Nenhuma peça fora do kit e da paleta. Nenhum `Label3D`.
- Todas as zonas com colisão e sem buracos no chão fora dos "vãos" propositais.
- Teste de regressão do mapa (3.8).
- `docs/MAPAS.md` ganha a seção "Setor Zero" (como o Distrito Neon e a Obra têm).

### 3.8 Testes e o que você NÃO consegue fazer

- Escreva testes em `tests/regression/` no padrão dos existentes (`EscadaObra`, `ParedeInvisivel`...): carregar o
  mapa, colocar o jogador de teste no spawn e **comprovar** que ele vence cada obstáculo (vão do humano, viga
  agachado, zona silenciosa, vão do lobo, plataformas, parede de corrida); que o vão de reset devolve à marca; e
  que todo alvo está ao alcance do tiro da posição da etapa.
- **Você não roda Forward+ em tempo útil** e não vê o visual: **não afirme** que está bonito. Entregue o mapa
  com o script de fotos pronto (`tools/fotos_mapas.gd` já existe; confira se aceita um mapa novo) e escreva ao
  Jhon **exatamente** quais 8 ângulos fotografar (Núcleo, corredor, Linha de Fogo, Câmara, Arena, parede de
  corrida, Rua Ignição, Praça/Pinhal) para ele conferir e te devolver as fotos.
- Peças que o kit **não** tem (estátua do lobo, árvores, pinheiros, torre com antena, kiosque do café): **liste em
  `docs/MAPAS.md` → "Peças pendentes do Setor Zero"** com onde cada uma entra e uma sugestão de fonte com licença
  OK (ou "modelar no Blender, bloco de 4 m, `.glb`"). Use um **substituto honesto** (caixa/cilindro neutro com
  letreiro "PROVISÓRIO") até a peça chegar; **nunca** finja que a peça existe.

---

## 4. FASE 3 — As vozes da Iris

1. **Entrada:** os `.wav` de `vozes_tutorial_iris.zip` (mono 44,1 kHz, 16 bits, **nome** `voz_tutorial_<etapa>.wav`,
   por exemplo `voz_tutorial_1_0.wav`, `voz_tutorial_3_11.wav`). Copie para `assets/audio/` **só** os que o roteiro usa
   (não copie `extra_*` para o nome de etapa; veja o item 4).
2. **Nomes e resolução:** o jogo resolve `Sfx.Get("nome")` com `nome` e `nome_1..N`. Use o nome da etapa **sem
   extensão** (`voz_tutorial_1_0`). **Dicas:** `voz_tutorial_<etapa>_dica` (12 s) e `voz_tutorial_<etapa>_dica2`
   (25 s) quando existirem; **se não existir, o motor segue sem tocar** (legenda e marcador cobrem).
3. **Mapa etapa → arquivo no `roteiro.json`** (campo `voz`): nunca montar nome de arquivo por concatenação no código
   do motor sem checar `ResourceLoader.Exists`/`Sfx.Has`.
4. **Reservas:** `extra_clean`, `extra_take_your_time`, `extra_still_with_me`, `extra_welcome_back` entram como
   `voz_tutorial_reserva_clean`, `voz_tutorial_reserva_take_your_time`, `voz_tutorial_reserva_still_with_me`,
   `voz_tutorial_reserva_welcome_back` (`Sfx.Get` aceita `_1.._N`, então novas variações entram sem código).
   **"Nice." e "Exactly." não existem**: o código escolhe aleatoriamente entre as que existirem.
5. **Bus de áudio:** as falas da Iris tocam no mesmo bus das vozes do locutor (`voz_*`, veja `docs/AUDIO.md`), no
   volume do **locutor**, **sem** reverberação do mapa (como as demais vozes da Iris), e **nunca** são cortadas
   por SFX de combate (checar prioridade/ducking que o jogo já usa). Se a Iris falar e o jogador atirar, o tiro
   toca por cima; a fala **não** é interrompida.
6. **Sobreposição:** uma fala nova **só começa quando a anterior terminou** (fila). Se a etapa avançar rápido
   demais, a fala antiga termina antes da próxima (nada de duas Iris falando ao mesmo tempo).
7. **Tabela de conferência humana:** gere `docs/tutorial/CONFERENCIA_VOZES.md`: uma linha por arquivo (nome,
   duração em s, fala esperada em inglês, legenda em PT, **[ ] ouvi e confere**). Marque em **negrito** os pontos
   incertos (`1_3`, `1_4`, `1_6`, `2_0`, `2_5`, `2_6`, `3_1`, `3_2`). O Jhon ouve e assina; se algum estiver
   errado, o relatório pede o corte novo (você **não** tenta adivinhar um novo corte sem poder ouvir).
8. **Créditos e licença:** registre em `assets/audio/CREDITOS.md` (origem: ElevenLabs, voz "Jessica Anne Bogart —
   Eloquent Villain", plano **gratuito** em 25/11/2026, **sem uso comercial**, regerar em plano pago antes do
   lançamento) e `docs/SONS_IA.md`.
9. **Idioma:** as falas são **inglês** e a legenda segue o idioma do jogo (`assets/i18n/textos.csv`). A decisão
   "Iris também em português?" é do Jhon (item 5 de "A decidir"): **deixe o motor pronto para um segundo conjunto
   de vozes por idioma** (`voz_tutorial_pt_<etapa>`) sem implementá-lo.

---

## 5. FASE 4 — O motor do tutorial

### 5.1 Arquitetura (não misture com regra de jogo)

- **Dados, não código:** `assets/tutorial/roteiro.json` com as etapas. Um parser tolerante (campo desconhecido é
  ignorado e **logado**), e **um teste que valida o JSON** (ids únicos, `espera` conhecido, `voz` existente ou
  declarada ausente, legenda presente em `textos.csv`).
- **Máquina de etapas** `scripts/tutorial/TutorialRunner.cs` (nova pasta `scripts/tutorial/`), com estados:
  `Falando → Esperando → Concluida` (+ `PontoDeSalvamento`). Um **assinante de eventos** por etapa; quando o evento
  esperado chega, a etapa conclui, toca o **elogio** (se houver) e a próxima começa **só depois da fala terminar**.
- **Sem acoplar:** o runner **assina sinais** que o jogo já emite (tiro, recarga, troca de arma, transformação,
  abate, chama, uivo, parede) e adiciona só os eventos que faltam (5.3). **Não** altere `Health`, `Weapon` nem
  `FormController` para saber do tutorial; se precisar de um gancho, **um sinal/evento novo e neutro** no próprio
  sistema (ex.: `Weapon.Reloaded`), que qualquer um pode assinar.
- **HUD da Iris** `scripts/tutorial/TutorialHud.cs` (parente do `Hud`): **legenda** (embaixo, centro, fonte Barlow
  do jogo), **marcador de objetivo** (um losango com distância, estilo do jogo, apontando a próxima zona/alvo),
  **dica de tecla** (ícone da tecla **configurada**), **barra de progresso do bloco** discreta e o botão "Sair do
  treinamento" (Esc). Respeite `docs/UI.md` e os `UiTokens`/`UiKit`. **Teclas nunca em texto fixo**: leia de
  `InputSetup`/`InputMap` o evento ligado à ação (`{tecla:attack}` etc.; defina um formato de **token** nas legendas
  e resolva em tempo de exibição, incluindo teclas do mouse e gamepad se o jogo tiver).

### 5.2 Formato do `roteiro.json` (o mínimo)

```json
{
  "versao": 1,
  "blocos": [
    {
      "id": "bloco1", "titulo": "tutorial.bloco1",
      "etapas": [
        { "id": "1_0", "voz": "voz_tutorial_1_0",
          "legenda": "tutorial.1_0", "espera": { "tipo": "fala", "segundos": 3 } },
        { "id": "1_1", "voz": "voz_tutorial_1_1", "legenda": "tutorial.1_1",
          "espera": { "tipo": "olhar", "graus": 90 }, "dica": "voz_tutorial_1_1_dica",
          "dica_texto": "tutorial.1_1_dica", "tecla": "mouse_look" },
        { "id": "1_2", "voz": "voz_tutorial_1_2", "legenda": "tutorial.1_2",
          "espera": { "tipo": "zona", "zona": "marca_1" }, "marcador": "marca_1",
          "tecla": "move" },
        { "id": "1_6", "voz": "voz_tutorial_1_6", "legenda": "tutorial.1_6",
          "espera": { "tipo": "nenhuma" }, "salvar": true }
      ]
    }
  ]
}
```

Tipos de `espera` (todos documentados no `docs/TUTORIAL_ROTEIRO.md` ao fim): `fala`, `olhar`, `zona`,
`passou_vao`, `agachado_sob`, `devagar` (N s), `arma_slot` (slot), `abates` (N alvos, com opção "em sequência dentro
de T s"), `recarga`, `mira_acerto` (alvo longe, com botão de mira), `abate_com_n_tiros`, `coronhada_acerto`,
`faca_golpe`, `granada_no_alvo`, `transformou`, `golpes` (N), `corrida_quatro` (N s), `salto_carregado`,
`bote_acerto`, `parede` (N s), `parede_agarrou_saltou`, `uivo_completo`, `especial_usado`, `em_chamas`,
`hud_kp_brilho`, `guia_aberto` (N s), `tab_e_z`, `queda_forcada`, `renascer_aberto`, `conjunto_escolhido`,
`renasceu`. Cada um com **uma linha de teste**.

### 5.3 Eventos que faltam (o roteiro já avisou)

O jogo já tem tiro, recarga, troca de arma, transformação, abate, chama, uivo e parede. **Faltam** (você cria,
pequeno e neutro): **"chegou na zona"** (`TutorialZone`, `Area3D` com id), **"passou o vão"** (zona de pouso na
borda oposta, com a condição de ter saltado — não vale cair e voltar), **"agachado sob a viga"** (zona + estado
agachado + sem colidir), **"andou devagar N s"** (zona silenciosa + `_walking`/`_crouching` do `Player`) e
**"granada acertou o alvo"** (explosão dentro de R m do Dummy atrás do muro; R = o raio de dano da granada; confira
no código e use um valor que **exija** o arremesso por trás do muro, ou seja, a granada **não** pode matar o alvo
em linha reta). Cada evento novo ganha **teste**.

### 5.4 Portas, salvamento e retomada

- **A Iris abre uma porta por vez:** Núcleo → Linha de Fogo (bloco 2) → Câmara de Metamorfose (bloco 3) → Rua
  Ignição (bloco 4) → queda e Ponto de Retorno (bloco 5). **Ao terminar tudo, abra tudo** ("treino livre": o
  jogador volta a qualquer zona sem Iris; o marcador desaparece; esc → sair).
- **Pontos de salvamento** ao fim de cada bloco (etapas marcadas no roteiro): guarde o id da última etapa
  concluída **localmente** (o `ConfigFile`/ `user://` que o jogo já usa; **não** no servidor) e, ao reabrir, a
  Iris pergunta ("Welcome back. Pick up where we left off?") e retoma de lá. Sair no meio **nunca** perde a
  recompensa se a conta já a tiver recebido (ver 6).
- **Cair no vão:** reset suave na marca anterior (fade 0,3 s), **sem dano, sem morte, sem contar como derrota**.
- **Teclas:** o jogador pode ter remapeado. Toda dica e legenda resolve a tecla **configurada**.

### 5.5 As dicas (12 / 25 / 40 s)

Se o jogador não progride: dica falada aos **12 s**, uma segunda mais clara aos **25 s**, e aos **40 s** o jogo mostra
a **tecla na tela** (ícone grande, sem falar). **Errou 3 vezes seguidas:** "Take your time." (reserva). **Ficou 40 s
parado:** "Still with me?". Os tempos são `[Export]`/constantes em `docs/AJUSTES.md`. Se a dica falada **não existir**
como arquivo, o motor mostra **só a legenda** da dica (que está no CSV).

### 5.6 O treino de chamas (bloco 4) e o KP (blocos 4 e 5)

- **Em chamas:** `Rage.cs` é compartilhado com o servidor. **Não mude as constantes.** No treino, o runner **usa as
  regras reais** (3 abates seguidos dentro do prazo acendem a chama); se com as constantes atuais isso for
  inviável em 3 bonecos (verifique `KillHeat`/`Ignite`), **o runner injeta calor** (`Rage`) pela API pública em vez
  de mudar a regra, e **registra isso**.
- **KP no treino** (decisão do roteiro): os abates dos blocos 2–4 enchem o contador; **antes da queda**, o runner
  ajusta o saldo (do **treino**, nunca de partida real) para o bastante para pagar **um** conjunto e deixar **outro
  cinza**. O código chama KP de `WP` (`FormController.Wp`); o texto do jogo diz "kill points" por extenso na Iris e
  "KP" no HUD (o nome WP no código segue; a renomeação é outra pendência — **não** a faça aqui).
- **A queda (5.0):** um boneco de treino "derruba" o jogador (dano controlado e scriptado que mata **uma vez**) para
  a tela de renascer abrir. **O equipamento comprado some e os KP ficam** (regra real). A tela de renascer
  (`LoadoutMenu`) já existe: o treino **a usa**, com os 4 conjuntos de exemplo do próprio treino (padrão,
  e três de preços diferentes) e o **lobo**; o timeout de 5 s escolhe o **último usado** (como no jogo).

---

## 6. FASE 5 — Integração (entrada, Jogar → Treinamento, recompensa)

### 6.1 Entrada pós-login

Depois do **primeiro login** (conta nova) e antes do lobby: tela

> **Quer um treinamento rápido?** A Iris mostra o básico em 5 minutos.
> [ Começar ]   [ Agora não ]

"Agora não" leva ao lobby e deixa um **aviso discreto** em Jogar → Treinamento. Veja `AccountGate`/`LoginScreen`
para o ponto certo. Texto em `textos.csv` (PT e EN), no estilo do `docs/UI.md`.

### 6.2 Jogar → Treinamento (sempre disponível)

Um botão/modo **Treinamento** em Jogar (use o padrão do `ModePicker`/`RoomDirectory`: salas offline com bots).
Abre o Setor Zero com o runner. **Pode ser refeito quantas vezes quiser; a recompensa só na primeira.**

### 6.3 Dummy (boneco de treino)

`scripts/debug/Dummy.cs` hoje é de debug. Estenda **sem quebrar os testes** com **estados**: `parado`, `movel`
(segue trilho), `ataca` (o do bloco 5), `onda` (surge de um portão). Vida configurável (`2 tiros` da pistola, etc.),
**reaparece** depois de N s para quem quer treinar mais. Mantenha o resto do jogo ignorando-o (grupo próprio).

### 6.4 Servidor: concluído e recompensa

- **Recompensa única por conta.** Valor: **DECIDA E REGISTRE** com o Jhon (opções do roteiro: Presas, skin, título).
  Proponho **uma quantia pequena de Presas + um título cosmético** ("Recruta"), mas **só implemente depois que ele
  escolher**; até lá, deixe o valor num `[Export]` zerado e **documente**.
- Campo `tutorial_concluido_at timestamptz null` em `profiles` (**migração** no `Schema.cs`, nunca editando banco
  na mão), rota `POST /v1/tutorial/concluir` (idempotente: 2ª chamada devolve "já concluído" sem pagar de novo),
  **autenticada** pela sessão normal, **limite de taxa** como as outras rotas. Pague com o mesmo caminho de ganho
  que o fim de partida usa (`PgPlayerRepository`...), **não** com SQL solto, e registre no extrato.
- **Anti-trapaça:** o cliente diz "terminei"; o servidor **não confia**: aceite **uma vez por conta** e valor fixo,
  nunca proporcional ao que o cliente mandar. Sem número vindo do cliente.
- **Teste do servidor** em `servidor/Alcateia.Servidor.Testes` (idempotência, autenticação, valor fixo) e no
  painel: o Jogador mostra "tutorial concluído em ...".
- **Offline:** se o servidor cair, o treino **roda** e a conclusão **fica pendente** localmente e é reenviada no
  próximo login (sem duplicar).
- **Nunca** dê XP/nível por esse caminho sem decisão do Jhon.

---

## 7. Textos e idiomas (`assets/i18n/textos.csv`)

Toda legenda e todo texto de UI do tutorial entra como **chave** (`tutorial.<etapa>`) com **PT e EN**. As legendas em
PT são as do roteiro (coluna "Legenda (PT)"); o EN é a própria fala. Siga o fluxo do `tools/i18n/` que o repo
já tem (rode o script de conferência de chaves). **Token de tecla** nas legendas: `{tecla:attack}`,
`{tecla:crouch}`, `{tecla:reload}` etc. **Nunca** escreva "Shift", "Ctrl", "R" fixo numa legenda.

---

## 8. O que NÃO fazer

- Não renomear `WP`→`KP` no código (pendência separada).
- Não mexer em constantes de `Rage.cs`, nos custos do conjunto, nas regras de XP/nível/Presas.
- Não colocar o Setor Zero na rotação de mapas nem nas salas online.
- Não criar mecânica nova (o posto médico **não** cura; o café **não** dá nada).
- Não inventar asset sem licença; não importar modelo de outro jogo; não usar a imagem de referência como textura.
- Não gerar áudio novo (voz, som). Peça ao Jhon na lista de pendências.
- Não subir nada para o Fly, nem tag, nem commit.
- Não deixar o tutorial **obrigatório** em nenhum ponto (sempre dá para sair; "Agora não" existe).
- Não gastar o tempo do jogador: o tutorial tem **5 a 6 minutos**; se o seu fluxo passar de 8, **corte**.

---

## 9. O que depende do Jhon (você não consegue; deixe pronto e peça)

1. **Ouvir as vozes** (tabela de conferência) e regravar os cortes errados, as **dicas** (12 s/25 s), a etapa **4.3**
   ("Hold E any time to see your abilities.") e as reservas "Nice." e "Exactly.".
2. **Fotos do mapa** (8 ângulos listados na fase 2) e **jogar** o treino inteiro, reportando onde travou.
3. **Importar no Godot** (`godot --headless --import`) e conferir **Forward+** (a nuvem não roda).
4. **Escolher a recompensa** e se a Iris fala português também.
5. **Peças de arte** que o kit não tem (a lista de pendências do `MAPAS.md`).
6. **Regerar as vozes em plano pago** antes do lançamento.

---

## 10. Relatório final (formato obrigatório, em português, curto e honesto)

1. **O que foi feito** por fase (uma frase cada), com os arquivos principais.
2. **O que foi testado** e o resultado (`tools/testar.sh --rapido`: cole a saída resumida) e **o que NÃO foi
   testado** (visual, Forward+, voz, servidor real).
3. **Ajustes de física** que você precisou fazer na planta (vão do humano, alturas do lobo...), com os números
   finais e de onde vieram.
4. **Peças pendentes** (arte), **decisões em aberto** e **o que travou**.
5. **Riscos**: o que pode quebrar quando o Jhon abrir no Mac.
6. **Mensagem de commit sugerida** (não faça o commit).
7. **Próximo passo sugerido** (um só).

**Honestidade acima de aparência:** se algo não está pronto, diga "não está pronto". Prefira entregar **menos, de
verdade**, a entregar tudo "no papel".
