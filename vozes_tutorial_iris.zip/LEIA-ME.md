# Vozes do tutorial (Iris) — cortadas de um único MP3

Origem: ElevenLabs, voz "Jessica Anne Bogart - Eloquent Villain" (PVC), 162 s, mono 44,1 kHz.
O original está em `original/`. Os cortes foram feitos pelos silêncios e conferidos por
reconhecimento de fala automático (impreciso). **Ouça cada arquivo antes de usar.**

Nome = `voz_tutorial_<bloco>_<etapa>.wav` (etapas do `docs/TUTORIAL_ROTEIRO.md`).

## Faltando / sobrando
- **4.3** "Hold E any time to see your abilities." — não achei na gravação. Regravar.
- **4.1** é a voz do personagem ("I'm on fire"), já existe no jogo.
- **Dicas** (`_dica`, 12 s / 25 s): não estavam na gravação. Regravar.
- Reservas "Nice." e "Exactly." não achei. "Clean.", "Take your time.", "Still with me?" e "Welcome back..." estão como `extra_*`.
- `4_2b` e `4_2b_alt` são duas gravações da mesma fala (escolha uma). `4_2c` junta as duas frases.
- `sem_destino_44`: trecho de 1,8 s ("...still...") que não casa com nenhuma linha. Provavelmente descarte.

## Fala de cada arquivo (conforme o roteiro)
1_0 Welcome to the arena. I'm Iris. I'll be your voice out there. | 1_1 Look around. Move your mouse. | 1_2 Good. Now walk to the marker. | 1_3 Jump the gap. | 1_4 Crouch under the beam. | 1_5 Hold shift to walk quietly. Enemies can't hear you. | 1_6 Clean. That's the basics.
2_0 Time to arm up. Press 1... | 2_1 Hit the three targets. | 2_2 You're running low. Reload. | 2_3 Zoom in... far target. | 2_4 Switch to your pistol. Press 2. | 2_5 It's slower, but it hits hard. Two shots do the job. | 2_6 Close range? Melee. Press V. | 2_7 Your knife is on 4. | 2_8 Grenade. Press 5... behind the wall. | 2_9 Good. That's your arsenal.
3_0 ... 3_11 e 4_0, 4_2, 4_2b, 4_2c, 4_4, 5_0 ... 5_7, 6_0, 6_1: ver o roteiro.

## Atenção
Plano gratuito do ElevenLabs não permite uso comercial: regerar em plano pago antes do lançamento.
Os pontos de corte mais incertos: 1_3/1_4, 1_6/2_0, 2_5/2_6, 3_1/3_2.
